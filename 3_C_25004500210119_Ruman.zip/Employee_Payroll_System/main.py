"""
Employee Payroll Management System
Advanced educational CLI project using Python's standard library only.

Features:
- Employee registration and search
- Monthly payroll calculation
- Overtime, allowances, deductions, tax estimate
- Payslip display and payroll history
- JSON file persistence
- OOP, inheritance, lambda, comprehensions, sets, tuples, and exception handling

Note: Payroll rules here are simplified for learning, not legal or tax advice.
"""

import json
from datetime import datetime
from pathlib import Path

DATA_FILE = Path(__file__).with_name("payroll_data.json")


class PayrollError(Exception):
    """Base exception for payroll operations."""


class ValidationError(PayrollError):
    """Invalid user input or record values."""


class RecordNotFoundError(PayrollError):
    """Requested employee or payroll record does not exist."""


class Employee:
    """Base employee record."""

    def __init__(self, employee_id, name, age, phone, department, basic_salary):
        self.employee_id = str(employee_id).strip().upper()
        self.name = str(name).strip()
        self.age = int(age)
        self.phone = str(phone).strip()
        self.department = str(department).strip()
        self.basic_salary = float(basic_salary)

        if not self.employee_id or not self.name or not self.department:
            raise ValidationError("Employee ID, name, and department are required.")
        if not 18 <= self.age <= 100:
            raise ValidationError("Employee age must be between 18 and 100.")
        if not self.phone.isdigit() or len(self.phone) != 10:
            raise ValidationError("Phone number must contain exactly 10 digits.")
        if self.basic_salary <= 0:
            raise ValidationError("Basic salary must be greater than zero.")

    def to_dict(self):
        return {
            "id": self.employee_id,
            "name": self.name,
            "age": self.age,
            "phone": self.phone,
            "department": self.department,
            "basic_salary": round(self.basic_salary, 2),
            "role": "Employee",
        }


class PermanentEmployee(Employee):
    """Permanent employee with allowance and tax settings."""

    def __init__(self, employee_id, name, age, phone, department, basic_salary,
                 hra_percent=20, da_percent=10, tax_percent=5):
        super().__init__(employee_id, name, age, phone, department, basic_salary)
        self.hra_percent = float(hra_percent)
        self.da_percent = float(da_percent)
        self.tax_percent = float(tax_percent)
        for label, value in (
            ("HRA percentage", self.hra_percent),
            ("DA percentage", self.da_percent),
            ("Tax percentage", self.tax_percent),
        ):
            if not 0 <= value <= 100:
                raise ValidationError(f"{label} must be between 0 and 100.")

    def to_dict(self):
        data = super().to_dict()
        data.update({
            "role": "Permanent",
            "hra_percent": self.hra_percent,
            "da_percent": self.da_percent,
            "tax_percent": self.tax_percent,
        })
        return data


class PayrollRecord:
    """Stores a monthly salary calculation."""

    def __init__(self, record_id, employee_id, month, year, basic, hra, da,
                 overtime_pay, other_allowance, deductions, tax):
        self.record_id = str(record_id)
        self.employee_id = str(employee_id).upper()
        self.month = int(month)
        self.year = int(year)
        self.basic = float(basic)
        self.hra = float(hra)
        self.da = float(da)
        self.overtime_pay = float(overtime_pay)
        self.other_allowance = float(other_allowance)
        self.deductions = float(deductions)
        self.tax = float(tax)

        if not 1 <= self.month <= 12:
            raise ValidationError("Month must be from 1 to 12.")
        if not 2000 <= self.year <= 2100:
            raise ValidationError("Year must be between 2000 and 2100.")
        if any(value < 0 for value in (
            self.basic, self.hra, self.da, self.overtime_pay,
            self.other_allowance, self.deductions, self.tax
        )):
            raise ValidationError("Payroll amounts cannot be negative.")

    @property
    def gross_salary(self):
        return self.basic + self.hra + self.da + self.overtime_pay + self.other_allowance

    @property
    def net_salary(self):
        return self.gross_salary - self.deductions - self.tax

    def to_dict(self):
        return {
            "id": self.record_id,
            "employee_id": self.employee_id,
            "month": self.month,
            "year": self.year,
            "basic": round(self.basic, 2),
            "hra": round(self.hra, 2),
            "da": round(self.da, 2),
            "overtime_pay": round(self.overtime_pay, 2),
            "other_allowance": round(self.other_allowance, 2),
            "deductions": round(self.deductions, 2),
            "tax": round(self.tax, 2),
            "gross_salary": round(self.gross_salary, 2),
            "net_salary": round(self.net_salary, 2),
            "created_at": datetime.now().isoformat(timespec="seconds"),
        }


class PayrollSystem:
    def __init__(self, data_file=DATA_FILE):
        self.data_file = Path(data_file)
        self.employees = {}
        self.payroll_records = {}
        self.load_data()

    def load_data(self):
        if not self.data_file.exists():
            return
        try:
            with self.data_file.open("r", encoding="utf-8") as file:
                data = json.load(file)
            self.employees = data.get("employees", {})
            self.payroll_records = data.get("payroll_records", {})
        except (OSError, json.JSONDecodeError) as exc:
            raise PayrollError(
                f"Unable to read {self.data_file.name}: {exc}. "
                "Back up the file and check its JSON format."
            ) from exc

    def save_data(self):
        try:
            with self.data_file.open("w", encoding="utf-8") as file:
                json.dump({
                    "employees": self.employees,
                    "payroll_records": self.payroll_records,
                }, file, indent=4, ensure_ascii=False)
        except OSError as exc:
            raise PayrollError(f"Unable to save payroll data: {exc}") from exc

    @staticmethod
    def next_id(prefix, records):
        ids = [
            int(key[len(prefix):])
            for key in records
            if key.startswith(prefix) and key[len(prefix):].isdigit()
        ]
        return f"{prefix}{max(ids, default=0) + 1:03d}"

    def add_employee(self, name, age, phone, department, basic_salary,
                     employee_type="permanent"):
        employee_id = self.next_id("E", self.employees)
        if employee_type.strip().lower() == "permanent":
            employee = PermanentEmployee(
                employee_id, name, age, phone, department, basic_salary
            )
        elif employee_type.strip().lower() == "regular":
            employee = Employee(
                employee_id, name, age, phone, department, basic_salary
            )
        else:
            raise ValidationError("Employee type must be 'permanent' or 'regular'.")
        self.employees[employee_id] = employee.to_dict()
        self.save_data()
        return employee_id

    def require_employee(self, employee_id):
        employee_id = employee_id.strip().upper()
        if employee_id not in self.employees:
            raise RecordNotFoundError(f"Employee '{employee_id}' was not found.")
        return self.employees[employee_id]

    def calculate_payroll(self, employee_id, month, year, overtime_hours=0,
                          overtime_rate=0, other_allowance=0, deductions=0):
        employee_id = employee_id.strip().upper()
        employee = self.require_employee(employee_id)

        month, year = int(month), int(year)
        overtime_hours = float(overtime_hours)
        overtime_rate = float(overtime_rate)
        other_allowance = float(other_allowance)
        deductions = float(deductions)

        if overtime_hours < 0 or overtime_rate < 0 or other_allowance < 0 or deductions < 0:
            raise ValidationError("Overtime, allowances, and deductions cannot be negative.")
        if not 1 <= month <= 12:
            raise ValidationError("Month must be from 1 to 12.")
        if not 2000 <= year <= 2100:
            raise ValidationError("Year must be between 2000 and 2100.")

        basic = float(employee["basic_salary"])
        hra_percent = float(employee.get("hra_percent", 0))
        da_percent = float(employee.get("da_percent", 0))
        tax_percent = float(employee.get("tax_percent", 0))

        hra = basic * hra_percent / 100
        da = basic * da_percent / 100
        overtime_pay = overtime_hours * overtime_rate
        gross = basic + hra + da + overtime_pay + other_allowance
        tax = gross * tax_percent / 100

        # Prevent duplicate payroll records for the same employee and month.
        for record in self.payroll_records.values():
            if (record["employee_id"] == employee_id
                    and record["month"] == month and record["year"] == year):
                raise ValidationError(
                    "Payroll already exists for this employee and month/year."
                )

        record_id = self.next_id("PR", self.payroll_records)
        record = PayrollRecord(
            record_id, employee_id, month, year, basic, hra, da,
            overtime_pay, other_allowance, deductions, tax
        )
        self.payroll_records[record_id] = record.to_dict()
        self.save_data()
        return self.payroll_records[record_id]

    def search_employees(self, query):
        query = query.strip().casefold()
        return [
            employee for employee in self.employees.values()
            if query in employee["id"].casefold()
            or query in employee["name"].casefold()
            or query in employee["department"].casefold()
        ]

    def history_for_employee(self, employee_id):
        employee_id = employee_id.strip().upper()
        self.require_employee(employee_id)
        return sorted(
            [
                record for record in self.payroll_records.values()
                if record["employee_id"] == employee_id
            ],
            key=lambda record: (record["year"], record["month"]),
        )

    def summary(self):
        employee_count = len(self.employees)
        departments = {e["department"] for e in self.employees.values()}
        total_net_payroll = sum(
            record["net_salary"] for record in self.payroll_records.values()
        )
        # Tuple provides a compact summary result.
        return employee_count, len(departments), len(self.payroll_records), round(total_net_payroll, 2)


def money(amount):
    return f"₹{float(amount):,.2f}"


def print_employees(employees):
    print("\n--- EMPLOYEES ---")
    if not employees:
        print("No employees found.")
        return
    for employee in employees:
        print(
            f'{employee["id"]} | {employee["name"]} | Age {employee["age"]} | '
            f'{employee["department"]} | Basic: {money(employee["basic_salary"])} | '
            f'Type: {employee["role"]}'
        )


def print_payslip(record, employee):
    print("\n========== MONTHLY PAYSLIP ==========")
    print(f'Employee ID : {employee["id"]}')
    print(f'Name        : {employee["name"]}')
    print(f'Department  : {employee["department"]}')
    print(f'Period      : {record["month"]:02d}/{record["year"]}')
    print("-------------------------------------")
    print(f'Basic salary     : {money(record["basic"])}')
    print(f'HRA              : {money(record["hra"])}')
    print(f'DA               : {money(record["da"])}')
    print(f'Overtime pay     : {money(record["overtime_pay"])}')
    print(f'Other allowance  : {money(record["other_allowance"])}')
    print(f'Gross salary     : {money(record["gross_salary"])}')
    print(f'Deductions       : {money(record["deductions"])}')
    print(f'Estimated tax    : {money(record["tax"])}')
    print("-------------------------------------")
    print(f'NET SALARY       : {money(record["net_salary"])}')
    print("=====================================")


def prompt_int(prompt):
    try:
        return int(input(prompt).strip())
    except ValueError as exc:
        raise ValidationError("Please enter a whole number.") from exc


def prompt_float(prompt):
    try:
        return float(input(prompt).strip())
    except ValueError as exc:
        raise ValidationError("Please enter a valid number.") from exc


def show_menu():
    print("""
========= EMPLOYEE PAYROLL SYSTEM =========
1. Register employee
2. View all employees
3. Search employees
4. Calculate monthly payroll
5. View employee payroll history
6. View all payroll records
7. Dashboard summary
0. Save and exit
===========================================
""")


def run_cli():
    try:
        system = PayrollSystem()
    except PayrollError as exc:
        print("Startup error:", exc)
        return

    while True:
        show_menu()
        choice = input("Enter choice: ").strip()
        try:
            if choice == "1":
                name = input("Employee name: ")
                age = prompt_int("Age (18-100): ")
                phone = input("Phone (10 digits): ")
                department = input("Department: ")
                salary = prompt_float("Basic monthly salary (INR): ")
                employee_type = input("Type (permanent/regular) [permanent]: ").strip() or "permanent"
                employee_id = system.add_employee(
                    name, age, phone, department, salary, employee_type
                )
                print(f"Employee registered. Employee ID: {employee_id}")

            elif choice == "2":
                employees = sorted(
                    system.employees.values(),
                    key=lambda employee: employee["name"].casefold()
                )
                print_employees(employees)

            elif choice == "3":
                query = input("Search by employee ID, name, or department: ")
                print_employees(system.search_employees(query))

            elif choice == "4":
                employee_id = input("Employee ID: ")
                month = prompt_int("Month (1-12): ")
                year = prompt_int("Year (e.g. 2026): ")
                overtime_hours = prompt_float("Overtime hours [0]: ")
                overtime_rate = prompt_float("Overtime rate per hour [0]: ")
                allowance = prompt_float("Other allowance [0]: ")
                deductions = prompt_float("Other deductions [0]: ")
                record = system.calculate_payroll(
                    employee_id, month, year, overtime_hours,
                    overtime_rate, allowance, deductions
                )
                employee = system.require_employee(employee_id)
                print_payslip(record, employee)

            elif choice == "5":
                employee_id = input("Employee ID: ")
                history = system.history_for_employee(employee_id)
                employee = system.require_employee(employee_id)
                if not history:
                    print("No payroll history found.")
                else:
                    for record in history:
                        print_payslip(record, employee)

            elif choice == "6":
                records = sorted(
                    system.payroll_records.values(),
                    key=lambda record: (record["year"], record["month"], record["employee_id"])
                )
                print("\n--- PAYROLL RECORDS ---")
                if not records:
                    print("No payroll records found.")
                for record in records:
                    print(
                        f'{record["id"]} | {record["employee_id"]} | '
                        f'{record["month"]:02d}/{record["year"]} | '
                        f'Gross {money(record["gross_salary"])} | '
                        f'Net {money(record["net_salary"])}'
                    )

            elif choice == "7":
                employee_count, department_count, record_count, total_net = system.summary()
                print("\n--- DASHBOARD SUMMARY ---")
                print("Employees:", employee_count)
                print("Departments:", department_count)
                print("Payroll records:", record_count)
                print("Total net payroll:", money(total_net))

            elif choice == "0":
                system.save_data()
                print("Data saved. Goodbye!")
                break

            else:
                print("Invalid choice. Select a number from the menu.")

        except (PayrollError, ValueError, TypeError) as exc:
            print("Error:", exc)
        except KeyboardInterrupt:
            print("\nInterrupted. Saving data...")
            system.save_data()
            break


if __name__ == "__main__":
    run_cli()
