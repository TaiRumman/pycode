EMPLOYEE PAYROLL MANAGEMENT SYSTEM — QUICK START

1. Install Python 3.
2. Extract this ZIP file.
3. Open the extracted folder in VS Code.
4. Run main.py, or type `python main.py` in the terminal.
5. Use menu option 0 to save and exit.

See Documentation.md for payroll formulas, validation, Python concepts, and test ideas.
This is an educational demo; payroll and tax rules are simplified.
