# Employee Payroll Management System

## 1. Overview

This is an advanced, menu-driven Python project for maintaining employee records and calculating monthly payroll. It stores data locally in JSON and uses only Python's standard library.

**Important:** This project uses simplified, configurable percentages for educational demonstrations. It is not a substitute for current Indian payroll, tax, PF, ESI, or labour-law advice. Verify real payroll calculations with a qualified professional.

## 2. Files

- `main.py` — complete application and menu
- `Documentation.md` — detailed project documentation
- `README.txt` — quick-start guide
- `payroll_data.json` — automatically created when records are saved

## 3. Run in VS Code

1. Extract the ZIP.
2. Open the extracted `Employee_Payroll_System` folder in VS Code.
3. Open `main.py`.
4. Run the file, or open the terminal and enter:

   ```bash
   python main.py
   ```

   On Windows, `py main.py` may also work.

No additional pip packages are required.

## 4. Features

1. Register an employee as `permanent` or `regular`.
2. View all employees sorted by name.
3. Search employees by ID, name, or department.
4. Calculate monthly payroll and display a payslip.
5. View an employee's payroll history.
6. View all payroll records.
7. View dashboard counts and total net payroll.
8. Persist employees and payroll records in JSON.

## 5. Payroll calculation

For a permanent employee, default percentages are:
- HRA = 20% of basic salary
- DA = 10% of basic salary
- Estimated tax = 5% of gross salary

The program computes:

```text
HRA = Basic Salary × HRA Percentage / 100
DA = Basic Salary × DA Percentage / 100
Overtime Pay = Overtime Hours × Overtime Rate
Gross Salary = Basic + HRA + DA + Overtime Pay + Other Allowance
Estimated Tax = Gross Salary × Tax Percentage / 100
Net Salary = Gross Salary − Other Deductions − Estimated Tax
```

Regular employees have no default HRA, DA, or tax percentages in this demo. These rules are intentionally simplified for practice and should not be used to process actual payroll.

### Example

For a permanent employee with basic salary ₹30,000, 5 overtime hours at ₹200/hour, ₹1,000 other allowance, and ₹500 other deductions:

- HRA = ₹6,000
- DA = ₹3,000
- Overtime = ₹1,000
- Gross = ₹41,000
- Estimated tax (5%) = ₹2,050
- Net = ₹38,450

## 6. Input validation

- Employee name and department are required.
- Age must be between 18 and 100.
- Phone number must be exactly 10 digits.
- Basic salary must be greater than zero.
- Percentages must be between 0 and 100.
- Overtime, allowances, and deductions cannot be negative.
- Month must be 1 through 12.
- Year must be 2000 through 2100.
- Duplicate payroll for the same employee and month/year is rejected.

## 7. Object-oriented design

- `Employee`: base employee class.
- `PermanentEmployee`: inherits from `Employee`.
- `PayrollRecord`: calculates gross and net salary.
- `PayrollSystem`: handles registration, search, payroll calculations, history, and JSON persistence.
- `PayrollError`, `ValidationError`, and `RecordNotFoundError`: custom exception classes.

## 8. Python concepts demonstrated

| Concept | Example in project |
|---|---|
| Variables and data types | Employee fields and payroll amounts |
| Functions | Registration, calculation, search, persistence |
| Lambda | Sorting employees by name |
| List | Search results and payroll history |
| Tuple | Dashboard summary result |
| Set | Unique department count |
| Dictionary | JSON-compatible employee/payroll records |
| Comprehensions | Search results and summary calculations |
| File handling | Reading/writing JSON |
| Exception handling | Validation and file errors |
| OOP and inheritance | `Employee` and `PermanentEmployee` |
| Properties | `gross_salary` and `net_salary` |
| Date/time | Payroll record creation timestamp |

## 9. Suggested test workflow

1. Register a permanent employee with valid details.
2. Register a regular employee.
3. Search by department or employee name.
4. Calculate payroll for a month with overtime and deductions.
5. Try to create payroll for the same employee and month again; it should be rejected.
6. View the employee's payroll history.
7. Exit and reopen the application; saved data should remain.
8. Try an invalid phone number or negative deduction; validation should reject it.

## 10. Data and safety notes

- Data is saved to `payroll_data.json` beside `main.py`.
- Back up the JSON file before manual edits.
- JSON storage is suitable for a classroom demo, not a secure multi-user payroll service.
- The demo does not encrypt sensitive employee data or implement authentication, permissions, statutory tax slabs, payslip PDFs, or bank transfers.
- Use fictional employee data for demonstrations.
